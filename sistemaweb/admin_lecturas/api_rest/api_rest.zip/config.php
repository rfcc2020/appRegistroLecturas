<?php

$db = [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'db' => 'baselecturas' //Cambiar al nombre de tu base de datos
];

?>