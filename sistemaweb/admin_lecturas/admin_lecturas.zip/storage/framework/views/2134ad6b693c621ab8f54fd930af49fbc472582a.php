<?php $__env->startSection('content'); ?>
    <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Fecha</th>
                <th>Detalle</th>
                <th>Observación</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Sector</th>
                <th>Codigo</th>
            </tr>                            
        </thead>
        <tbody>
            <?php $__currentLoopData = $requerimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requerimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($requerimiento->id); ?></td>
                <td><?php echo e($requerimiento->fecha); ?></td>
                <td><?php echo e($requerimiento->detalle); ?></td>
                <td><?php echo e($requerimiento->observacion); ?></td>
                <td><?php echo e($requerimiento->nombre); ?></td>
                <td><?php echo e($requerimiento->apellido); ?></td>
                <td><?php echo e($requerimiento->sector); ?></td>
                <td><?php echo e($requerimiento->codigo); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>