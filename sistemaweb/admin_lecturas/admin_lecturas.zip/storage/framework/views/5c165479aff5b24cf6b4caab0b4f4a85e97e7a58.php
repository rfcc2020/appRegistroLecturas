<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Abonados
                    <?php if (\Shinobi::can('personas.create')): ?>
                    <a href="<?php echo e(route('personas.create')); ?>" 
                    class="btn btn-sm btn-primary pull-right">
                        Crear
                    </a>
                    <?php endif; ?>                
                    <a href="<?php echo e(route('personas.pdf')); ?>" class="btn btn-sm btn-primary pull-right">
                        Reporte en PDF
                    </a>    
                </div>

                <div class="panel-body">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="10px">ID</th>
                                <th>Cédula</th>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th colspan="3">&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($persona->id); ?></td>
                                <td><?php echo e($persona->cedula); ?></td>
                                <td><?php echo e($persona->nombre); ?></td>
                                <td><?php echo e($persona->apellido); ?></td>
                                <?php if (\Shinobi::can('personas.show')): ?>
                                <td width="10px">
                                    <a href="<?php echo e(route('personas.show', $persona->id)); ?>" 
                                    class="btn btn-sm btn-default">
                                        ver
                                    </a>
                                </td>
                                <?php endif; ?>
                                <?php if (\Shinobi::can('personas.edit')): ?>
                                <td width="10px">
                                    <a href="<?php echo e(route('personas.edit', $persona->id)); ?>" 
                                    class="btn btn-sm btn-default">
                                        editar
                                    </a>
                                </td>
                                <?php endif; ?>
                                <?php if (\Shinobi::can('personas.destroy')): ?>
                                <td width="10px">
                                    <?php echo Form::open(['route' => ['personas.destroy', $persona->id], 
                                    'method' => 'DELETE']); ?>

                                        <button class="btn btn-sm btn-danger">
                                            Eliminar
                                        </button>
                                    <?php echo Form::close(); ?>

                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($personas->render()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>