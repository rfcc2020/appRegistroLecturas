<?php $__env->startSection('content'); ?>
    <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Fecha</th>
                <th>Nombre</th>
                <th>Detalle</th>
                <th>Observación</th>
                <th>Valor</th>               
                <th>Sector</th>
                <th>Codigo</th>
            </tr>                            
        </thead>
        <tbody>
            <?php $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notificacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($notificacion->id); ?></td>
                <td><?php echo e($notificacion->fecha); ?></td>
                <td><?php echo e($notificacion->nombre); ?> <?php echo e($notificacion->apellido); ?></td>
                <td><?php echo e($notificacion->detalle); ?></td>
                <td><?php echo e($notificacion->observacion); ?></td>                
                 <td><?php echo e($notificacion->valor); ?></td>
                <td><?php echo e($notificacion->sector); ?></td>
                <td><?php echo e($notificacion->codigo); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>