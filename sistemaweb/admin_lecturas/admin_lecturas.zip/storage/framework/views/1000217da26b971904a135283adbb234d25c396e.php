<div class="form-group">
	<?php echo e(Form::label('name', 'Nombre de la etiqueta')); ?>

	<?php echo e(Form::text('name', null, ['class' => 'form-control', 'id' => 'name'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('description', 'Descripción')); ?>

	<?php echo e(Form::textarea('description', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

</div>