<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Abonado</div>

                <div class="panel-body">                                        
                    <p><strong>Cédula</strong>      <?php echo e($persona->cedula); ?></p>
                    <p><strong>Nombre</strong>      <?php echo e($persona->nombre); ?></p>
                    <p><strong>Apellido</strong>    <?php echo e($persona->apellido); ?></p>
                    <p><strong>Teléfono</strong>    <?php echo e($persona->telefono); ?></p>
                    <p><strong>Email</strong>      <?php echo e($persona->email); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>