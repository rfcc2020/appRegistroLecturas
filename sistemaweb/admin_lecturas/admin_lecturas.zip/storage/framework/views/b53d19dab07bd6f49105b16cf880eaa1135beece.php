<div class="form-group">
	<?php echo e(Form::label('Fecha', 'Fecha')); ?>

	<?php echo e(Form::date('fecha', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Detalle', 'Detalle')); ?>

	<?php echo e(Form::text('detalle', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Valor', 'Valor')); ?>

	<?php echo e(Form::text('valor', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Observacion', 'Observacion')); ?>

	<?php echo e(Form::text('observacion', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Imagen', 'Imagen')); ?>

	<?php echo e(Form::file('imagen', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('idmedidor', 'Id de medidor')); ?>

	<?php echo e(Form::text('medidor_id', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Estado', 'Estado')); ?>

	<?php echo e(Form::checkbox('estado', 'A', true, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

</div>