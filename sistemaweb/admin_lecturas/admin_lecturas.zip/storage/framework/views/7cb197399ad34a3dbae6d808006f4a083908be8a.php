<div class="form-group">
	<?php echo e(Form::label('Codigo', 'Codigo')); ?>

	<?php echo e(Form::text('codigo', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Número', 'Número')); ?>

	<?php echo e(Form::text('numero', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Marca', 'Marca')); ?>

	<?php echo e(Form::text('marca', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Modelo', 'Modelo')); ?>

	<?php echo e(Form::text('modelo', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Sector', 'Sector')); ?>

	<?php echo e(Form::select('sector', array('la union' => 'La Unión', 'portete' => 'Portete','pedregal' => 'Pedregal','rayoloma' => 'Rayoloma'), 'S', ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Imagen', 'Imagen')); ?>

	<?php echo e(Form::file('imagen', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('idpersona', 'Id del Abonado')); ?>

	<?php echo e(Form::text('persona_id', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

</div>