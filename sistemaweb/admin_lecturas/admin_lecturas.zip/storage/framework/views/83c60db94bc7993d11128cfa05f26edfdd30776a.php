<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-body">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="10px">ID</th>
                                <th>Código</th>
                                <th>Numero</th>
                                <th colspan="3">&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $medidores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medidor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($medidor->id); ?></td>
                                <td><?php echo e($medidor->codigo); ?></td>
                                <td><?php echo e($medidor->numero); ?></td>
                                <?php if (\Shinobi::can('medidores.show')): ?>
                                <td width="10px">
                                    <a href="<?php echo e(route('medidores.show', $medidor->id)); ?>" 
                                    class="btn btn-sm btn-default">
                                        ver
                                    </a>
                                </td>
                                <?php endif; ?>
                                <?php if (\Shinobi::can('medidores.asignar')): ?>
                                <td width="10px">
                                    <a href="<?php echo e(route('medidores.asignar', $medidor->id, $persona_id)); ?>" 
                                    class="btn btn-sm btn-default">
                                        asignar
                                    </a>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($medidores->render()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>