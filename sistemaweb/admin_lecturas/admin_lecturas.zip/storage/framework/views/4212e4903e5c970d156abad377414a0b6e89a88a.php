<div class="form-group">
	<?php echo e(Form::label('Cédula', 'Cédula')); ?>

	<?php echo e(Form::text('cedula', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Nombre', 'Nombre')); ?>

	<?php echo e(Form::text('nombre', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Apellido', 'Apellido')); ?>

	<?php echo e(Form::text('apellido', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Teléfono', 'Teléfono')); ?>

	<?php echo e(Form::text('telefono', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('Email', 'Email')); ?>

	<?php echo e(Form::email('email', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

</div>