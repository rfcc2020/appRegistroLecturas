<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Requerimiento</div>

                <div class="panel-body">                                        
                    <p><strong>Fecha</strong>      <?php echo e($requerimiento->cedula); ?></p>
                    <p><strong>Detalle</strong>      <?php echo e($requerimiento->nombre); ?></p>
                    <p><strong>Observacion</strong>    <?php echo e($requerimiento->apellido); ?></p>
                    <p><strong>Nombre</strong>    <?php echo e($requerimiento->telefono); ?></p>
                    <p><strong>Apellido</strong>      <?php echo e($requerimiento->email); ?></p>
                    <p><strong>Sector</strong>  <?php echo e($requerimiento->sector); ?></p>
                    <img class="card-img-top" src="http://localhost/admin_lecturas/public/images/<?php echo e($requerimiento->imagen); ?>" alt="">
                    <p><strong>Estado</strong>  <?php echo e($requerimiento->estado); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>