<?php $__env->startSection('content'); ?>
    <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Nombre</th>
                <th>Anterior</th>
                <th>Actual</th>
                <th>Consumo</th>
                <th>Básico</th>
                <th>Exceso</th>
            </tr>                            
        </thead>
        <tbody>
            <?php $__currentLoopData = $lecturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lectura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>              
            <td><?php echo e($lectura->id); ?></td>
            <td><?php echo e($lectura->fecha); ?></td>
            <td><?php echo e($lectura->nombre); ?> <?php echo e($lectura->apellido); ?></td>
            <td><?php echo e($lectura->anterior); ?></td>
            <td><?php echo e($lectura->actual); ?></td>
            <td><?php echo e($lectura->consumo); ?></td>
            <td><?php echo e($lectura->basico); ?></td>
            <td><?php echo e($lectura->exceso); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>